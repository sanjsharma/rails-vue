// require theme/js/jquery-3.2.1.min
// require theme/js/bootstrap.min
// require theme/js/bootstrap-select
// require theme/js/bootstrap-notify
// require theme/js/light-bootstrap-dashboard
// require theme/js/chartist.min
// require theme/js/demo
;
